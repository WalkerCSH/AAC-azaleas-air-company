package aac.domain.dataCategory;

public enum TripType {

    ROUND, ONE_WAY, MULTI_WAY;
   
}
