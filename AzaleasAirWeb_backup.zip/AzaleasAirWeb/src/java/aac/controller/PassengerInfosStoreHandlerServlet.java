/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aac.controller;

import aac.domain.Passenger;
import aac.domain.PassengerList;
import aac.domain.dataCategory.Country;
import aac.domain.dataCategory.Gender;
import aac.domain.dataCategory.PassengerType;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Administrator
 */
@WebServlet(name = "PassengerInfosStoreHandlerServlet", urlPatterns = {"/passenger_seats_select.jsp"})
public class PassengerInfosStoreHandlerServlet extends HttpServlet {

    private final String failed = "/booking_system.jsp";
    private final String succeed = "/booking_system.jsp";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<String> errors = new ArrayList<>();
        HttpSession session = request.getSession();
        session.removeAttribute("errorlist");

        String[] passengerArr = {"passenger_r", "passenger_1", "passenger_2", "passenger_3"};
        PassengerList pl = (PassengerList) session.getAttribute("passenger_list");
        int totalPassengers = pl.getAdultNumber() + pl.getChildNumber();

        // 1. 取得ajax請求中的form data
        String[] firstnames = new String[]{"", "", "", ""};
        String[] lastnames = new String[]{"", "", "", ""};
        String[] gendersStr = new String[]{"", "", "", ""};
        String[] birthes = new String[]{"", "", "", ""};
        String[] residenceStr = new String[]{"", "", "", ""};
        for (int i = 0; i < totalPassengers; i++) {
            firstnames[i] = request.getParameter("firstname_" + passengerArr[i]).trim().toUpperCase();
            lastnames[i] = request.getParameter("lastname_" + passengerArr[i]).trim().toUpperCase();
            gendersStr[i] = request.getParameter("gender_" + passengerArr[i]).trim();
            birthes[i] = request.getParameter("birthday_" + passengerArr[i]).trim();
            residenceStr[i] = request.getParameter("residence_" + passengerArr[i]).trim();
        }
        for (int i = 0; i < totalPassengers; i++) {
            if (firstnames == null || firstnames[i].length() <= 0) {
                errors.add(passengerArr[i] + " firstname需要完整輸入");
            }
            if (!firstnames[i].matches("[A-Z]+")) {
                errors.add(passengerArr[i] + " firstname需要使用大寫英文輸入並且與護照相同: " + firstnames[i]);
            }
            if (lastnames == null || lastnames[i].length() <= 0) {
                errors.add(passengerArr[i] + " lastname需要完整輸入");
            }
            if (!lastnames[i].matches("[A-Z]+")) {
                errors.add(passengerArr[i] + " lastname需要使用大寫英文輸入並且與護照相同: " + lastnames[i]);
            }
            if (gendersStr == null || gendersStr[i].length() <= 0) {
                errors.add(passengerArr[i] + " genders需要完整輸入");
            }
            if (birthes == null || birthes[i].length() <= 0) {
                errors.add(passengerArr[i] + " birthes需要完整輸入");
            }
            if (residenceStr == null || residenceStr[i].length() <= 0) {
                errors.add(passengerArr[i] + " residence需要完整輸入");
            }
        }
        SimpleDateFormat sdfDateOnly = new SimpleDateFormat("yyyy-MM-dd");
        int adult = pl.getAdultNumber();
        int child = pl.getChildNumber();
        int[] genders = new int[]{0, 0, 0, 0};
        int[] residence = new int[]{0, 0, 0, 0};
        if (errors.isEmpty()) {
            for (int i = 0; i < totalPassengers; i++) {
                genders[i] = Integer.parseInt(gendersStr[i]);
                residence[i] = Integer.parseInt(residenceStr[i]);
            }
            try {
                Passenger[] pgArr = {null, null, null, null};
                for (int i = 0; i < totalPassengers; i++) {
                    Passenger p = new Passenger();
                    if (adult > 0) {
                        p.setPassengerType(PassengerType.ADULT);
                        --adult;
                    } else if (child > 0) {
                        p.setPassengerType(PassengerType.CHILD);
                        --child;
                    } else {
                        System.out.println("Infant不需要輸入資料");
                    }
                    p.setFirstName(firstnames[i]);
                    p.setLastName(lastnames[i]);
                    p.setGender(Gender.values()[genders[i]]);
                    p.setBirthday(sdfDateOnly.parse(birthes[i]));
                    p.setResidence(Country.values()[residence[i]]);
                    pgArr[i] = p;
                }
                pl.setPassengerInfo(pgArr);
                session.setAttribute("bs_page", 2);
                session.setAttribute("passenger_list", pl);
                session.setAttribute("complete", 1);
                response.sendRedirect(request.getContextPath() + succeed);
                return;
            } catch (Exception ex) {
                this.log("系統發生非預期的錯誤" + ex.getMessage(), ex);
                errors.add("系統發生非預期的錯誤" + ex.getMessage());
            }
        }

        Passenger[] pgArr = {null, null, null, null};
        try {
            for (int i = 0; i < totalPassengers; i++) {
                Passenger p = new Passenger();
                if (adult > 0) {
                    p.setPassengerType(PassengerType.ADULT);
                    --adult;
                } else if (child > 0) {
                    p.setPassengerType(PassengerType.CHILD);
                    --child;
                } else {
                    System.out.println("Infant不需要輸入資料");
                }
                p.setFirstName(firstnames[i]);
                p.setLastName(lastnames[i]);
                p.setGender(Gender.values()[genders[i]]);
                p.setBirthdayStr(birthes[i]);
                p.setResidence(Country.values()[residence[i]]);
                pgArr[i] = p;
            }
        } catch (Exception ex) {
            this.log("系統發生非預期的錯誤" + ex.getMessage(), ex);
            errors.add("系統發生非預期的錯誤" + ex.getMessage());
        }
        pl.setPassengerInfo(pgArr);        
        session.setAttribute("passenger_list", pl);
        session.setAttribute("errorlist", errors);
        for (String str : errors) {
            System.out.println("errors: " + str);
        }
        session.setAttribute("bs_page", 2);
        session.setAttribute("complete", -1);
        request.getRequestDispatcher(failed).forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        processRequest(request, response);
//    }
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
