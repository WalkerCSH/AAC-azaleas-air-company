/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aac.controller;

import aac.domain.Customer;
import aac.domain.Flight;
import aac.domain.dataCategory.Airport;
import aac.domain.dataCategory.FlightRoute;
import aac.domain.dataCategory.TripType;
import aac.domain.PassengerList;
import aac.domain.SeatsSelectedSet;
import aac.domain.TicketOrder;
import aac.domain.dataCategory.CabinClass;
import aac.domain.dataCategory.Country;
import aac.domain.flight.SeatDistribute;
import aac.model.PriceSheetServices;
import aac.model.service.CustomerServices;
import aac.model.service.FlightSellingStatusServices;
import aac.model.service.PassengerListServices;
import aac.model.service.PassengerServices;
import aac.model.service.SeatsSelectedSetServices;
import aac.model.service.TicketOrderServices;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Administrator
 */
@WebServlet(name = "BookingSystemServlet", urlPatterns = {"/booking_system"})
public class BookingSystemServlet extends HttpServlet {

    private final String search_failed = "/";
    private final String search_succeed = "/booking_system.jsp";
    private final String failed = "/booking_system.jsp";
    private final String succeed = "/booking_system.jsp";
    private final boolean redirect = true;
    private String[] passenger_name_ch = {"旅客代表", "同行旅客1", "同行旅客2", "同行旅客3"};

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequestSearch(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        // 1. 取得請求中的form data
        List<String> errors = new ArrayList<>();
        String departureStr = request.getParameter("departure");
        int departure = 0;
        if (departureStr.matches("\\d+")) {
            departure = Integer.parseInt(departureStr);
            if (!(departure >= 0 && departure <= Airport.values().length)) {
                errors.add("出發地出現錯誤");
            }
        } else {
            errors.add("出發地出現錯誤");
        }
        String destinationStr = request.getParameter("destination");
        int destination = 0;
        if (destinationStr.matches("\\d+")) {
            destination = Integer.parseInt(destinationStr);
            if (!(destination >= 0 && destination <= Airport.values().length)) {
                errors.add("目的地出現錯誤");
            }
        } else {
            errors.add("目的地出現錯誤");
        }

        String flightTypeStr = request.getParameter("flight_type");
        int flightType = 0;
        Date departureDate = null, returnDate = null;
        FlightRoute departFlightRoute = null;
        FlightRoute returnFlightRoute = null;
        SimpleDateFormat sdfDateOnly = new SimpleDateFormat("yyyy-MM-dd");
        if (flightTypeStr != null && flightTypeStr.equalsIgnoreCase("0")) {
            try {
                departureDate = sdfDateOnly.parse(request.getParameter("booking_departure_date"));
                returnDate = sdfDateOnly.parse(request.getParameter("booking_return_date"));
                flightType = 0;
                departFlightRoute = FlightRoute.matchFlightRouteName(departure, destination);
                returnFlightRoute = FlightRoute.matchFlightRouteName(destination, departure);
            } catch (ParseException ex) {
                Logger.getLogger(BookingSystemServlet.class.getName()).log(Level.SEVERE, null, ex);
                errors.add("出發或返回日期出現錯誤");
            }
        } else if (flightTypeStr != null && flightTypeStr.equalsIgnoreCase("1")) {
            try {
                departureDate = sdfDateOnly.parse(request.getParameter("booking_departure_date"));
                flightType = 1;
                departFlightRoute = FlightRoute.matchFlightRouteName(departure, destination);
            } catch (ParseException ex) {
                Logger.getLogger(BookingSystemServlet.class.getName()).log(Level.SEVERE, null, ex);
                errors.add("出發日期出現錯誤");
            }
        } else {
            errors.add("飛行類型錯誤");
        }

        String coupon = request.getParameter("coupon");

        int[] passengers = {1, 0, 0};
        String adultStr = request.getParameter("adult");
        String childStr = request.getParameter("child");
        String infantStr = request.getParameter("infant");
        if (!(adultStr.matches("\\d+")) || !(childStr.matches("\\d+")) || !(infantStr.matches("\\d+"))) {
            errors.add("乘客數量錯誤");
        } else {
            passengers[0] = Integer.parseInt(adultStr);
            passengers[1] = Integer.parseInt(childStr);
            passengers[2] = Integer.parseInt(infantStr);
        }
        if (passengers[0] < passengers[2]) {
            errors.add("每一位幼兒都需要一位12歲以上的乘客陪同");
        } else if ((passengers[0] + passengers[1]) > 4) {
            errors.add("人數超過訂位上限");
        }

        if (errors.isEmpty()) {
            // 2. 建立TicketOrder物件儲存資料 再將該物件放在session中 
            try {
                TicketOrder to = new TicketOrder();
                to.setFlightType(TripType.values()[flightType]);
                to.setDepartFlightRoute(departFlightRoute);
                to.setDepartDate(departureDate);
                to.setCoupon(coupon);
                if (flightType == 0) {
                    to.setReturnFlightRoute(returnFlightRoute);
                    to.setReturnDate(returnDate);
                }
                PassengerList pl = new PassengerList();
                pl.setPassengers(passengers);
                session.setAttribute("ticket_order", to);
                session.setAttribute("passenger_list", pl);
                if (redirect) {
                    // 3.1 當流程成功 將頁面指引放入session 頁面回到booking_system 後開啟對應include                    
                    session.setAttribute("bs_page", 1);
                    response.sendRedirect(request.getContextPath() + search_succeed); // sendRedirect外部轉交
                }
                return;
            } catch (Exception ex) {
                this.log("系統發生非預期的錯誤" + ex.getMessage(), ex);
                errors.add("系統發生非預期的錯誤" + ex.getMessage());
            }
        }
        // 3.2 當流程失敗 回到index 在後台顯示錯誤
        for (String str : errors) {
            System.out.println("errors: " + str);
        }
        session.setAttribute("bs_page", 0);
        session.setAttribute("errorlist", errors);
        request.getRequestDispatcher(search_failed).forward(request, response);
    }

    protected void processRequestFlightSelect(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<String> errors = new ArrayList<>();
        HttpSession session = request.getSession();
        TicketOrder to = (TicketOrder) session.getAttribute("ticket_order"); // 從session中取出to物件

        // 1. 取得請求中的form data
        int departFlightClassInt = Integer.parseInt(request.getParameter("depart_flight_class_value"));
        int returnFlightClassInt = -1;
        if (to.getTripType().ordinal() == 0) {
            returnFlightClassInt = Integer.parseInt(request.getParameter("return_flight_class_value"));
        }
        CabinClass ccd = null;
        CabinClass ccr = null;
        if (departFlightClassInt >= 0) {
            ccd = CabinClass.values()[departFlightClassInt];
        } else {
            errors.add("出發航班艙等錯誤");
        }
        if (to.getTripType().ordinal() == 0) {
            if (returnFlightClassInt >= 0) {
                ccr = CabinClass.values()[returnFlightClassInt];
            } else {
                errors.add("返回航班艙等錯誤");
            }
        }
        if (errors.isEmpty()) {
            try {
                // 2. 將由此頁面接受的資料儲存入to 另外運算出價格資訊 最後將該物件與價格資訊一同放回session中
                CabinClass[] cabinClass = new CabinClass[]{ccd, ccr};
                to.setCabinClass(cabinClass);
                session.setAttribute("ticket_order", to);

                PassengerList pl = (PassengerList) session.getAttribute("passenger_list");
                PriceSheetServices pss = new PriceSheetServices();
                int priceDepart = pss.getPriceByDateAndFlightRouteAndClass(to.getDepartDate(), to.getDepartFlightRoute(), to.getCabinClass()[0]);
                int priceReturn = 0;
                if (to.getTripType().ordinal() == 0) {
                    priceReturn = pss.getPriceByDateAndFlightRouteAndClass(to.getReturnDate(), to.getReturnFlightRoute(), to.getCabinClass()[0]);
                }
                int departAmount = (int) ((pl.getAdultNumber() + pl.getChildNumber() * 0.5 + pl.getInfantNumber() * 0.1) * priceDepart);
                int returnAmount = (int) ((pl.getAdultNumber() + pl.getChildNumber() * 0.5 + pl.getInfantNumber() * 0.1) * priceReturn);
                int totalamount = departAmount + returnAmount;
                int[] pricelist = {totalamount, departAmount, returnAmount};
                session.setAttribute("pricelist", pricelist);
                if (redirect) {
                    // 3.1 當流程成功 將頁面指引放入session 頁面回到booking_system 後開啟對應include                     
                    session.setAttribute("bs_page", 2);
                    response.sendRedirect(request.getContextPath() + succeed); // sendRedirect外部轉交
                }
                return;
            } catch (Exception ex) {
                this.log("系統發生非預期的錯誤" + ex.getMessage(), ex);
                errors.add("系統發生非預期的錯誤" + ex.getMessage());
            }
        }

        // 3.2 當流程失敗 回到booking_system並顯示錯誤
        session.setAttribute("errorlist", errors);
        for (String str : errors) {
            System.out.println("errors: " + str);
        }
        session.setAttribute("bs_page", 1);
        request.getRequestDispatcher(failed).forward(request, response);
    }

    protected void processRequestPassengerService(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<String> errors = new ArrayList<>();
        HttpSession session = request.getSession();
        PassengerList pl = (PassengerList) session.getAttribute("passenger_list");
        SeatsSelectedSet sss = (SeatsSelectedSet) session.getAttribute("seatsSelectedSet");
        // 1. 檢查pl中的顧客基本資訊與座位資訊是否皆完成輸入        
        if (pl == null || pl.getPassengerInfo() == null) {
            errors.add("旅客資料未完整輸入...");
        }
        if (sss == null) {
            errors.add("選位資料未完整輸入...");
        }

        // 2.1 當檢查成功 將頁面指引放入session 頁面回到booking_system 後開啟對應include
        if (errors.isEmpty()) {
            try {
                session.setAttribute("bs_page", 3);
                response.sendRedirect(request.getContextPath() + succeed);
                return;
                // 2.2 當流程失敗 回到booking_system並顯示錯誤
            } catch (Exception ex) {
                this.log("系統發生非預期的錯誤" + ex.getMessage(), ex);
                errors.add("系統發生非預期的錯誤" + ex.getMessage());
            }
        }
        session.setAttribute("errorlist", errors);
        for (String str : errors) {
            System.out.println("errors: " + str);
        }
        session.setAttribute("bs_page", 2);
        request.getRequestDispatcher(failed).forward(request, response);
    }

    protected void processRequestPassengerSeatsSelect(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<String> errors = new ArrayList<>();
        HttpSession session = request.getSession();
        TicketOrder to = (TicketOrder) session.getAttribute("ticket_order");
        PassengerList pl = (PassengerList) session.getAttribute("passenger_list");
        int totalPassengers = pl.getAdultNumber() + pl.getChildNumber();

        String[] depart_seats_name = {"depart_seats_selected_R", "depart_seats_selected_1",
            "depart_seats_selected_2", "depart_seats_selected_3"};
        String[] return_seats_name = {"return_seats_selected_R", "return_seats_selected_1",
            "return_seats_selected_2", "return_seats_selected_3"};

        // 1. 取得請求中的form data        
        String departSeatsSelectedR = "";
        String departSeatsSelected1 = "";
        String departSeatsSelected2 = "";
        String departSeatsSelected3 = "";
        String[] departSeatsSelectedList = {departSeatsSelectedR, departSeatsSelected1,
            departSeatsSelected2, departSeatsSelected3};

        for (int i = 0; i < totalPassengers; i++) {
            if (request.getParameter(depart_seats_name[i]) == null) {
                errors.add(passenger_name_ch[i] + " 去程未選位");
            } else {
                departSeatsSelectedList[i] = request.getParameter(depart_seats_name[i]);
                if (departSeatsSelectedList[i].length() <= 0) {
                    errors.add(passenger_name_ch[i] + " 去程未選位");
                }
            }
        }

        String returnSeatsSelectedR = "";
        String returnSeatsSelected1 = "";
        String returnSeatsSelected2 = "";
        String returnSeatsSelected3 = "";

        String[] returnSeatsSelectedList = new String[]{returnSeatsSelectedR, returnSeatsSelected1,
            returnSeatsSelected2, returnSeatsSelected3};
        if (to.getTripType().ordinal() == 0) {
            for (int i = 0; i < totalPassengers; i++) {
                if (request.getParameter(return_seats_name[i]) == null) {
                    errors.add(passenger_name_ch[i] + " 回程未選位");
                } else {
                    returnSeatsSelectedList[i] = request.getParameter(return_seats_name[i]);
                    if (returnSeatsSelectedList[i] == null || returnSeatsSelectedList[i].length() <= 0) {
                        errors.add(passenger_name_ch[i] + " 回程未選位");
                    }
                }
            }
        }
        // 2. 檢查若無錯誤 則將資料儲存入sss 再將該物件放回session中
        if (errors.isEmpty()) {
            try {
                SeatsSelectedSet sss
                        = new SeatsSelectedSet(
                                departSeatsSelectedList[0], departSeatsSelectedList[1], departSeatsSelectedList[2], departSeatsSelectedList[3],
                                returnSeatsSelectedList[0], returnSeatsSelectedList[1], returnSeatsSelectedList[2], returnSeatsSelectedList[3]
                        );
                session.setAttribute("seatsSelectedSet", sss);
                // 3.1 當流程成功 將頁面指引放入session 頁面回到booking_system 後開啟對應include
                session.setAttribute("bs_page", 2);
                response.sendRedirect(request.getContextPath() + succeed);
                return;
            } catch (Exception ex) {
                this.log("系統發生非預期的錯誤" + ex.getMessage(), ex);
                errors.add("系統發生非預期的錯誤" + ex.getMessage());
            }
        }
        // 3.2 當流程失敗 回到booking_system並顯示錯誤
        session.setAttribute("errorlist", errors);
        for (String str : errors) {
            System.out.println("errors: " + str);
        }
        session.setAttribute("bs_page", 21);
        request.getRequestDispatcher(failed).forward(request, response);
    }

    protected void processRequestCreditPay(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<String> errors = new ArrayList<>();
        HttpSession session = request.getSession();

        String[] passengerArr = {"passenger_r", "passenger_1", "passenger_2", "passenger_3"};
        PassengerList pl = (PassengerList) session.getAttribute("passenger_list");
        int totalPassengers = pl.getAdultNumber() + pl.getChildNumber();
        // 1. 取得請求中的form data
        String[] nationsStr = new String[]{"", "", "", ""};
        String[] passnumbers = new String[]{"", "", "", ""};
        String[] issLocationsStr = new String[]{"", "", "", ""};
        String[] passExpirys = new String[]{"", "", "", ""};
        for (int i = 0; i < totalPassengers; i++) {
            nationsStr[i] = request.getParameter("nation_" + passengerArr[i]);
            passnumbers[i] = request.getParameter("passport_number_" + passengerArr[i]);
            issLocationsStr[i] = request.getParameter("issue_location_" + passengerArr[i]);
            passExpirys[i] = request.getParameter("passport_expiry_date_" + passengerArr[i]);
        }
        for (int i = 0; i < totalPassengers; i++) {
            if (nationsStr[i].length() <= 0) {
                errors.add(passenger_name_ch[i] + "nation需要完整輸入");
            }
            if (passnumbers[i].length() <= 0) {
                errors.add(passenger_name_ch[i] + "passport_number需要完整輸入");
            }
            if (issLocationsStr[i].length() <= 0) {
                errors.add(passenger_name_ch[i] + "issue_location需要完整輸入");
            }
            if (passExpirys[i].length() <= 0) {
                errors.add(passenger_name_ch[i] + "passport_expiry_date需要完整輸入");
            }
        }
        String customerEmail = request.getParameter("customer_email");
        String customerEmailRepeat = request.getParameter("customer_email_repeat");
        if (customerEmail.isEmpty()) {
            errors.add("電子郵件信箱未輸入");
        } else if (customerEmailRepeat.isEmpty()) {
            errors.add("電子郵件信箱確認欄位未輸入");
        } else if (!Customer.checkEmail(customerEmail) || !Customer.checkEmail(customerEmailRepeat)) {
            errors.add("電子郵件信箱格式輸入錯誤");
        } else if (!customerEmail.equalsIgnoreCase(customerEmailRepeat)) {
            errors.add("電子郵件信箱與確認欄位內容不符");
        }
        String customerPhone = request.getParameter("customer_phone");
        if (customerPhone.isEmpty()) {
            errors.add("連絡電話未輸入");
        } else if (!customerPhone.matches("[0-9]{8,}")) {
            errors.add("連絡電話格式輸入錯誤");
        }
        String creditPayInfoKeyinNumberStr = request.getParameter("ticketorder_credit_pay_info_keyin_number");
        if (creditPayInfoKeyinNumberStr.isEmpty()) {
            errors.add("信用卡號未輸入");
        } else if (!creditPayInfoKeyinNumberStr.matches("[0-9]{16}")) {
            errors.add("信用卡號格式輸入錯誤");
        }
        String creditPayInfoKeyinExpiryMonthStr = request.getParameter("ticketorder_credit_pay_info_keyin_expiry_month");
        if (creditPayInfoKeyinExpiryMonthStr.isEmpty()) {
            errors.add("卡片效期月份未輸入");
        } else if (!creditPayInfoKeyinExpiryMonthStr.matches("\\d+")) {
            errors.add("卡片效期月份格式輸入錯誤");
        }
        String creditPayInfoKeyinExpiryYearStr = request.getParameter("ticketorder_credit_pay_info_keyin_expiry_year");
        if (creditPayInfoKeyinExpiryYearStr.isEmpty()) {
            errors.add("卡片效期年份未輸入");
        } else if (!creditPayInfoKeyinExpiryYearStr.matches("\\d+")) {
            errors.add("卡片效期年份格式輸入錯誤");
        }
        String creditPayInfoKeyinCCVStr = request.getParameter("credit_pay_info_keyin_ccvnumber");
        if (creditPayInfoKeyinCCVStr.isEmpty()) {
            errors.add("驗證號碼未輸入");
        } else if (!creditPayInfoKeyinCCVStr.matches("[0-9]{3}")) {
            errors.add("驗證號碼格式輸入錯誤");
        }
        SimpleDateFormat sdfDateOnly = new SimpleDateFormat("yyyy-MM-dd");
        if (errors.isEmpty()) {
            try {
                FlightSellingStatusServices fsss = new FlightSellingStatusServices();
                TicketOrder to = (TicketOrder) session.getAttribute("ticket_order");
                SeatsSelectedSet sss = (SeatsSelectedSet) session.getAttribute("seatsSelectedSet");

                Flight departFlight = new Flight(to.getDepartDate(), to.getDepartFlightRoute());
                departFlight = fsss.search(departFlight.getId());
                SeatDistribute sdd = new SeatDistribute(departFlight.getType());
                String[] departSeatSelectedSets
                        = {sss.getDepartSeatR(), sss.getDepartSeat1(), sss.getDepartSeat2(), sss.getDepartSeat3()};
                for (int i = 0; i < totalPassengers; i++) {
                    sdd.selectSeat(departSeatSelectedSets[i]);
                }

                Flight returnFlight = null;
                SeatDistribute sdr = null;
                String[] returnSeatSelectedSets = null;
                if (to.getTripType().ordinal() == 0) {
                    returnFlight = new Flight(to.getReturnDate(), to.getReturnFlightRoute());
                    returnFlight = fsss.search(returnFlight.getId());

                    sdr = new SeatDistribute(returnFlight.getType());
                    returnSeatSelectedSets
                            = new String[]{sss.getReturnSeatR(), sss.getReturnSeat1(), sss.getReturnSeat2(), sss.getReturnSeat3()};
                    for (int i = 0; i < totalPassengers; i++) {
                        sdr.selectSeat(returnSeatSelectedSets[i]);
                    }
                }

                // 2. 先進行選位檢查 確認完成後 
                // 再將資料放入Customer、Passenger、TicketOrder等物件 並連同所有session中的資料 放入對應的mySQL tables中
                fsss.seatsSelected(departFlight, sdd);
                if (to.getTripType().ordinal() == 0) {
                    fsss.seatsSelected(returnFlight, sdr);
                }

                int[] nations = new int[]{0, 0, 0, 0};
                int[] issLocations = new int[]{0, 0, 0, 0};
                for (int i = 0; i < totalPassengers; i++) {
                    nations[i] = Integer.parseInt(nationsStr[i]);
                    issLocations[i] = Integer.parseInt(issLocationsStr[i]);
                }

                PassengerServices ps = new PassengerServices();
                PassengerListServices pls = new PassengerListServices();
                SeatsSelectedSetServices ssss = new SeatsSelectedSetServices();
                for (int i = 0; i < totalPassengers; i++) {
                    pl.getPassengerInfo()[i].setNation(Country.values()[nations[i]]);
                    pl.getPassengerInfo()[i].setPassportNumber(passnumbers[i]);
                    pl.getPassengerInfo()[i].setPassportIssuePlace(Country.values()[issLocations[i]]);
                    pl.getPassengerInfo()[i].setPassportExpiryDate(sdfDateOnly.parse(passExpirys[i]));
                    ps.create(pl.getPassengerInfo()[i]);
//                    System.out.println("pid" + i + " = " + pl.getPassengerInfo()[i].getId());                    
                }
                pls.build(pl);
                to.setPassengerListId(pl.getId());
                ssss.build(sss);
                to.setSeatsSelectedSetId(sss.getId());

                Customer c = new Customer(pl.getPassengerInfo()[0]);
                c.setEmail(customerEmail);
                c.setMobile(customerPhone);
                c.setCardNumber(creditPayInfoKeyinNumberStr);
                Calendar cal = new GregorianCalendar();
                cal.set(Integer.parseInt(creditPayInfoKeyinExpiryYearStr),
                        Integer.parseInt(creditPayInfoKeyinExpiryMonthStr) - 1, 1);
                c.setCardExpiryDate(cal.getTime());
                c.setCardCCV(creditPayInfoKeyinCCVStr);

                CustomerServices cs = new CustomerServices();
                cs.create(c);
                to.setCustomerId(c.getId());
                int[] pricelist = (int[]) session.getAttribute("pricelist");
                to.setGrossPrice(pricelist[0]);
                to.setStatus(TicketOrder.Status.ACCEPTED);
                to.setOrderTime();
                to.setOrderNumber(TicketOrder.generateOrderNumber());

                TicketOrderServices tos = new TicketOrderServices();
                tos.build(to);

                // 3.1 當流程成功 將頁面指引放入session 頁面回到booking_system 後開啟對應include
                session.removeAttribute("pricelist");
                session.removeAttribute("passenger_list");
                session.removeAttribute("ticket_order");

                TicketOrder tod = tos.findById(to.getId());
                PassengerList pld = pls.find(to.getPassengerListId());

                session.setAttribute("ticket_order_done", tod);
                session.setAttribute("passenger_list_done", pld);

                session.setAttribute("bs_page", 4);
                response.sendRedirect(request.getContextPath() + search_succeed);
                return;
            } catch (Exception ex) {
                this.log("系統發生非預期的錯誤" + ex.getMessage(), ex);
                errors.add("系統發生非預期的錯誤" + ex.getMessage());
            }
        }
        // 3.2 當流程失敗 回到前一頁面顯示錯誤 並且帶回所有已輸入的值
        try {
            int[] nations = new int[]{0, 0, 0, 0};
            int[] issLocations = new int[]{0, 0, 0, 0};
            for (int i = 0; i < totalPassengers; i++) {
                nations[i] = Integer.parseInt(nationsStr[i]);
                issLocations[i] = Integer.parseInt(issLocationsStr[i]);
            }
            for (int i = 0; i < totalPassengers; i++) {
                pl.getPassengerInfo()[i].setNation(Country.values()[nations[i]]);
                pl.getPassengerInfo()[i].setPassportNumber(passnumbers[i]);
                pl.getPassengerInfo()[i].setPassportIssuePlace(Country.values()[issLocations[i]]);
//                pl.getPassengerInfo()[i].setPassportExpiryDate(sdfDateOnly.parse(passExpirys[i]));
            }
        } catch (Exception ex) {
            this.log("系統發生非預期的錯誤" + ex.getMessage(), ex);
            errors.add("系統發生非預期的錯誤" + ex.getMessage());
        }
        session.setAttribute("passenger_list", pl);
        session.setAttribute("errorlist", errors);
        for (String str : errors) {
            System.out.println("errors: " + str);
        }
        session.setAttribute("bs_page", 3);
        request.getRequestDispatcher(failed).forward(request, response);
    }

    protected void processRequestPageToSeatsSelect(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        // 1.  將頁面指引放入session 頁面回到booking_system 後開啟對應include
        session.setAttribute("bs_page", 21);
        response.sendRedirect(request.getContextPath() + search_succeed);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        session.removeAttribute("errorlist");
        processRequestPageToSeatsSelect(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String urlOring = (String) session.getAttribute("url_origin");
        session.removeAttribute("errorlist");
        // 0. 系統分流
        if (urlOring.endsWith("aac/")) {
            session.removeAttribute("url_origin");
            processRequestSearch(request, response);
        } else if (((Integer) session.getAttribute("bs_page")) == 0) {
            session.removeAttribute("bs_page");
            processRequestSearch(request, response);
        } else if (((Integer) session.getAttribute("bs_page")) == 1) {
            session.removeAttribute("bs_page");
            processRequestFlightSelect(request, response);
        } else if (((Integer) session.getAttribute("bs_page")) == 2) {
            session.removeAttribute("bs_page");
            processRequestPassengerService(request, response);
        } else if (((Integer) session.getAttribute("bs_page")) == 21) {
            session.removeAttribute("bs_page");
            processRequestPassengerSeatsSelect(request, response);
        } else if (((Integer) session.getAttribute("bs_page")) == 3) {
            session.removeAttribute("bs_page");
            processRequestCreditPay(request, response);
        } else {
            session.setAttribute("path", "出現意外的錯誤路徑");
            response.sendRedirect(request.getContextPath());
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
