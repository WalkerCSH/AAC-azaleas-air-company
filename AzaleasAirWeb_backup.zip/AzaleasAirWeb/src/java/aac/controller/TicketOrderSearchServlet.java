/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aac.controller;

import aac.domain.Customer;
import aac.domain.PassengerList;
import aac.domain.TicketOrder;
import aac.model.service.CustomerServices;
import aac.model.service.PassengerListServices;
import aac.model.service.TicketOrderServices;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Walker
 */
@WebServlet(name = "TicketOrderSearchServlet", urlPatterns = {"/ticketorder_search"})
public class TicketOrderSearchServlet extends HttpServlet {

    private final String search_renew_failed = "/";
    private final String search_renew_succeed = "/ticketorder_search.jsp";
    private final boolean redirect = true;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<String> errors = new ArrayList<>();
        HttpSession session = request.getSession();
        String toOrderNumber = request.getParameter("tickerorder_ordernumber").trim();
        if (!TicketOrder.checkOrderNumber(toOrderNumber)) {
            errors.add("訂單代號格式錯誤");
        }
        TicketOrderServices tos = new TicketOrderServices();
        CustomerServices cs = new CustomerServices();
        String customerEmail = null;

        TicketOrder to = new TicketOrder();
        Customer c = new Customer();
        try {
            to = tos.findByOrderNumber(toOrderNumber);
            c = cs.find(to.getCustomerId());
            customerEmail = c.getEmail();
        } catch (Exception ex) {
            this.log("系統發生非預期的錯誤" + ex.getMessage(), ex);
            errors.add("系統發生非預期的錯誤" + ex.getMessage());
        }

        String toEmail = request.getParameter("tickerorder_email").trim();
        if (!Customer.checkEmail(toEmail)) {
            errors.add("Email格式錯誤");
        } else if (!toEmail.equalsIgnoreCase(customerEmail)) {
            errors.add("Email與資料不符");
        }

        if (errors.isEmpty()) {
            try {
                PassengerListServices pls = new PassengerListServices();
                PassengerList pl = pls.find(to.getPassengerListId());

                session.setAttribute("ticket_order", to);
                session.setAttribute("customer", c);
                session.setAttribute("passenger_list", pl);
                response.sendRedirect(request.getContextPath() + search_renew_succeed);
                return;
            } catch (Exception ex) {
                this.log("系統發生非預期的錯誤" + ex.getMessage(), ex);
                errors.add("系統發生非預期的錯誤" + ex.getMessage());
            }
        }
        for (String str : errors) {
            System.out.println("errors: " + str);
        }
        session.setAttribute("errors", errors);
        request.getRequestDispatcher(search_renew_failed).forward(request, response);
    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        processRequest(request, response);
//    }
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
