package aac.domain.dataCategory;

public enum CreditCard {

    VISA, MASTER_CARD, JCB;
   

}
