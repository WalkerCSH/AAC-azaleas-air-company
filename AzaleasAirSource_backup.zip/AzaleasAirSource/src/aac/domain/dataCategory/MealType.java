package aac.domain.dataCategory;

public enum MealType {

    MEAT, VEGETARIAN, FRUIT, MUSLIMS, BUDDHISM, HINDUISN;

    private int id;
    private String name;

    @Override
    public String toString() {
        return super.toString(); //To change body of generated methods, choose Tools | Templates.
    }

}
