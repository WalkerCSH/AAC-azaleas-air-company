package aac.domain.dataCategory;

public enum PassengerType {

    ADULT, CHILD, INFANT;
   
}
