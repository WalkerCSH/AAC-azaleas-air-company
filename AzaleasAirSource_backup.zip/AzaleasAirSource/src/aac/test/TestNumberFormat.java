/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aac.test;

import java.text.DecimalFormat;
import java.text.NumberFormat;

/**
 *
 * @author Administrator
 */
public class TestNumberFormat {
    public static void main(String[] args) {
        NumberFormat formatter = new DecimalFormat("#");
        
        
        
        // 參考資料 : http://www.dk101.com/Discuz/archiver/?tid-23861.html
    }
}
