/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aac.controller;

import aac.domain.TicketOrder;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Administrator
 */
@WebServlet(name = "DateChangerServlet", urlPatterns = {"/flight_select.jsp"})
public class DateChangerServlet extends HttpServlet {
    
    private final String search_renew_failed = "/";
    private final String search_renew_succeed = "/booking_system.jsp";
    private final boolean redirect = true;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    protected void processRequestDateChanger(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<String> errors = new ArrayList<>();

        SimpleDateFormat sdfDateOnly = new SimpleDateFormat("yyyy-MM-dd");
        HttpSession session = request.getSession();
        TicketOrder to = (TicketOrder) session.getAttribute("ticket_order");

        // 1. 取得ahax請求中的form data
        String departDateStr = (String) request.getParameter("departDateStr");
        String returnDateStr = (String) request.getParameter("returnDateStr");
        Date newDepartDate = to.getDepartDate();
        Date newReturnDate = to.getReturnDate();
        if (departDateStr != null) {
            try {
                newDepartDate = sdfDateOnly.parse(departDateStr);
            } catch (ParseException ex) {
                Logger.getLogger(DateChangerServlet.class.getName()).log(Level.SEVERE, "更改出發日期格式錯誤", ex);
                errors.add("更改出發日期格式錯誤");
            }
        }
        if (returnDateStr != null) {
            try {                
                newReturnDate = sdfDateOnly.parse(returnDateStr);
                if(newReturnDate.compareTo(newDepartDate)<0){
                    newReturnDate = newDepartDate;
                }
            } catch (ParseException ex) {
                Logger.getLogger(DateChangerServlet.class.getName()).log(Level.SEVERE, "更改返回日期格式錯誤", ex);
                errors.add("更改返回日期格式錯誤");
            }
        }
        if (errors.isEmpty()) {
            // 2. 建立TicketOrder物件儲存資料 再將該物件放在session中 
            try {
                to.setDepartDate(newDepartDate);
                to.setReturnDate(newReturnDate);
                session.setAttribute("ticket_order", to);
                // 3.1 當流程成功 將頁面指引放入session 頁面回到booking_system 後開啟對應include
                if (redirect) {
                    session.setAttribute("bs_page", 1);
//                    response.sendRedirect(request.getContextPath() + search_renew_succeed);
                }
                return;
            } catch (Exception ex) {
                this.log("系統發生非預期的錯誤" + ex.getMessage(), ex);
                errors.add("系統發生非預期的錯誤" + ex.getMessage());
            }
        }
        request.setAttribute("errors", errors);
        request.getRequestDispatcher(search_renew_failed).forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        processRequest(request, response);
//    }
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String urlOrigin = (String) session.getAttribute("url_origin");
        // 0. 系統分流
        if (urlOrigin.endsWith("aac/")) {
            processRequest(request, response);
        } else if (((Integer) session.getAttribute("bs_page")) == 1) {
            session.removeAttribute("booking_system_section");
            processRequestDateChanger(request, response);
        } else {
            session.setAttribute("path", "出現意外的錯誤路徑");
            response.sendRedirect(request.getContextPath());
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
