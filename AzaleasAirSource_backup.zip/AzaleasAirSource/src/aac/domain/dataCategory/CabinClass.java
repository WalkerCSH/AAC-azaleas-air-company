package aac.domain.dataCategory;

public enum CabinClass {

    GLORY, FANCY, HAPPY;
   

    public static CabinClass getGLORY() {
        return GLORY;
    }

    public static CabinClass getFANCY() {
        return FANCY;
    }

    public static CabinClass getHAPPY() {
        return HAPPY;
    }


}
